create view doc_view2 as
select `hospital`.`doctor`.`doc_id`       AS `doc_id`,
       `hospital`.`doctor`.`doc_name`     AS `doc_name`,
       `hospital`.`doctor`.`doc_dep`      AS `doc_dep`,
       `hospital`.`department`.`dep_addr` AS `dep_addr`
from `hospital`.`doctor`
         join `hospital`.`department`
where ((`hospital`.`doctor`.`doc_dep` = `hospital`.`department`.`dep_name`) and
       (`hospital`.`doctor`.`doc_sex` = 'female'));

