create view doc_view as
select `hospital`.`doctor`.`doc_id` AS `doid`, `hospital`.`doctor`.`doc_name` AS `doname`
from `hospital`.`doctor`;

